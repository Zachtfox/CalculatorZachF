import UIKit

var a = 1
var b = 2
var c = 5
var d = 8
var x = 10
var y = 15
var z = 4

var add = a + b
var sub = c - b
var multi = x * y
var div = y / c
var per = x % d

print(add)
print(sub)
print(multi)
print(div)
print(per)

